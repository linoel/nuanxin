AutoForm.setDefaultTemplate('ionic');
