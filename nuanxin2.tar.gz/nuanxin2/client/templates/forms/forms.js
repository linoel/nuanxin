AutoForm.hooks({
  'edit-form': {
    onSuccess: function (operation, result, template) {
      alert('Post saved successfully!');


      Posts.insert({
        persionId:Meteor.userId(),


      });
  //  if (userid)
    //Players.update(playId, {$inc: {score: 5}});
    /*
    if (Meteor.userId()) {


    }
    else {
      Records.insert({
        playerId:playId,
        voterId:Meteor.userId(),
        voterEmail: Meteor.user().emails[0].address,
        voterCounter: 1,
        });
    }
    */




      Router.go('/trending');
    //  Posts.insert();
    },

    onError: function(operation, error, template) {
      console.log(error);
    }
  }
});
