Meteor.startup(function () {
  AutoForm.setDefaultTemplate('ionic');
});
