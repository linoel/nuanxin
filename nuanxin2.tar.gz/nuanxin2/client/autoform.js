Meteor.startup(function () {
  T9n.setLanguage('zh-cn');
  AutoForm.setDefaultTemplate('ionic');
});
