![](public/favicon-96x96.png)

# [Meteor Hunt](http://meteorhunt.meteor.com/)

A [Product Hunt](http://www.producthunt.com/apps/ios) clone built using [meteoric:meteor-ionic](https://github.com/meteoric/meteor-ionic). **Currently in progress**

## Running the app

```
cp settings.json.example settings.json
meteor --settings settings.json
```
## License
[MIT License](https://github.com/meteoric/meteorhunt/blob/master/LICENSE)
